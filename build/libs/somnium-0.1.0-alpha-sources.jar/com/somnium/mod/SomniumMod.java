package com.somnium.mod;

import com.somnium.mod.command.TestDreamCommand;
import com.somnium.mod.command.SanityCommand;
import com.somnium.mod.dream.DreamRegistry;
import com.somnium.mod.event.BleedThroughManager;
import com.somnium.mod.registry.ModEntities;
import com.somnium.mod.registry.ModItems;
import com.somnium.mod.registry.ModSounds;
import com.somnium.mod.sanity.SanityManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Точка входа мода Somnium.
 *
 * Порядок инициализации важен:
 *  1. Регистрация сущностей / предметов / звуков (регистры должны быть готовы раньше всего)
 *  2. Регистрация реестра типов снов (DreamRegistry) — грузит data-driven JSON из data/somnium/dream
 *  3. Регистрация сетевых пакетов (синхронизация рассудка на клиент)
 *  4. Подписка на игровые события (сон, тик сервера, смерть/пробуждение)
 */
public final class SomniumMod implements ModInitializer {

    public static final String MOD_ID = "somnium";
    public static final Logger LOGGER = LoggerFactory.getLogger("Somnium");

    public static class_2960 id(String path) {
        return class_2960.method_43902(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        LOGGER.info("[Somnium] Границы между сном и явью начинают истончаться...");

        // 1. Базовые регистры
        ModEntities.register();
        ModEntities.registerAttributes();
        ModItems.register();
        // ИСПРАВЛЕНО: раньше предметы регистрировались, но никогда не попадали ни в одну
        // вкладку творческого режима — вызов ниже добавлен, чтобы они стали видны игроку.
        com.somnium.mod.registry.ModItemGroups.register();
        ModSounds.register();

        // ДОБАВЛЕНО: регистрация критериев достижений
        com.somnium.mod.advancement.ModCriteria.register();

        // 2. Реестр снов (data-driven, см. data/somnium/dream/*.json)
        DreamRegistry.bootstrap();

        // 3. Сетевые пакеты (рассудок -> клиент, для HUD)
        // В 1.20.1 не требуют регистрации через PayloadTypeRegistry

        // 4. Обработчики событий (перехват сна теперь реализован миксином PlayerEntityMixin —
        // см. src/main/java/com/somnium/mod/mixin/PlayerEntityMixin.java, регистрации в коде не требует)
        BleedThroughManager.register();

        // 5. Тик рассудка — раз в секунду (каждые 20 тиков) на каждого игрока
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 20 != 0) return;
            for (var player : server.method_3760().method_14571()) {
                SanityManager.tick(player);
                // Обновление постоянного HUD цели сна (полоса оставшегося времени) — раз в секунду,
                // этого достаточно для плавного отображения, не нагружая сеть каждым тиком.
                com.somnium.mod.dream.DreamManager.sendHudUpdateIfDreaming(player, server);
            }
        });

        // 6. Проверка таймаута активных снов (пробуждение по истечении времени сна) — каждый тик,
        // операция дешёвая (проход по карте активных снов, обычно пустой или очень маленькой).
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickActiveDreams);

        // 7. Проверка игроков, ожидающих перехода в сон (легли в кровать SLEEP_TRANSITION_TICKS
        // тиков назад) — переносит их в измерение сна уже на затемнённом экране.
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickPendingSleepTransitions);

        // 8. Очистка устаревших записей об окне неуязвимости при приземлении после
        // телепортации в сон/из сна (см. DreamManager#grantLandingImmunity).
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickLandingImmunity);

        // 9. ДОБАВЛЕНО ("добавь тревожную музыку", "никакого шёпота нету"): периодическая
        // фоновая атмосфера снов + "шёпот за спиной" в Лесу теней — раньше сны были полностью
        // немыми, кроме разовых тайтлов.
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickDreamAmbience);

        // 10. ДОБАВЛЕНО (сон "Падающие доски"): проверка таймеров удаления досок платформы
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickFallingPlanks);

        // 11. ДОБАВЛЕНО (сон "Падающие доски"): детектор падения игрока в пустоту = пробуждение
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::checkFallingPlanksVoidFall);

        // 12. ДОБАВЛЕНО (сон "Зеркальная комната"): проверка таймера разбивания стекла
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickMirrorRoomGlass);

        // 13. ДОБАВЛЕНО (сон "Тонущий город"): постепенный подъём уровня воды
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickDrowningCityWater);

        // 14. ДОБАВЛЕНО (сон "Сон-в-сне"): таблички за спиной игрока
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickDreamWithinDream);

        // 15. ДОБАВЛЕНО (сон "Лес теней"): ведьмины огни к Дереву-Маяку + проверка "не обернулся"
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickShadowForest);

        // 16. ДОБАВЛЕНО (сон "Обрушающаяся шахта"): проходы открываются/зарастают за спиной
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickCollapsingMine);

        // 17. ДОБАВЛЕНО (сон "Кровавый пир"): подача блюд, порча блюд, голодание/насыщение
        ServerTickEvents.END_SERVER_TICK.register(com.somnium.mod.dream.DreamManager::tickCrimsonFeast);

        // 18. ДОБАВЛЕНО (команда для тестирования): /testdream для быстрой телепортации в измерения снов
        CommandRegistrationCallback.EVENT.register(TestDreamCommand::register);
        // 19. ДОБАВЛЕНО ("добавь команды, чтобы влиять на шкалу рассудка"): /sanity get|set|add
        CommandRegistrationCallback.EVENT.register(SanityCommand::register);

        // 20. ДОБАВЛЕНО (мультиплеер, защита кровати): запрещаем разрушать кровати спящих игроков
        net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (state.method_26204() instanceof net.minecraft.class_2244) {
                if (com.somnium.mod.dream.DreamManager.isBedProtected(pos)) {
                    player.method_7353(net.minecraft.class_2561.method_43470("§cЭту кровать нельзя сломать — в ней кто-то спит!"), true);
                    return false; // отменяем разрушение
                }
            }
            return true; // разрешаем разрушение
        });

        // 21. ДОБАВЛЕНО (мультиплеер, колокол): удар в колокол будит спящих игроков в радиусе 5 блоков
        net.fabricmc.fabric.api.event.player.UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!(world instanceof net.minecraft.class_3218 serverWorld)) {
                return net.minecraft.class_1269.field_5811;
            }

            net.minecraft.class_2338 pos = hitResult.method_17777();
            net.minecraft.class_2680 state = world.method_8320(pos);

            if (state.method_26204() instanceof net.minecraft.class_3709) {
                // Звонящий сам во сне — разрешаем (в измерениях снов колоколов нет, но комментируем)
                // Если бы колокола были в снах, можно было бы добавить проверку:
                // if (com.somnium.mod.dream.DreamManager.isDreaming(player.getUuid())) return ActionResult.PASS;

                // Ищем спящих игроков в радиусе 5 блоков
                for (net.minecraft.class_3222 nearbyPlayer : serverWorld.method_18456()) {
                    if (nearbyPlayer.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) <= 25.0) { // 5^2 = 25
                        if (com.somnium.mod.dream.DreamManager.isDreaming(nearbyPlayer.method_5667())) {
                            com.somnium.mod.dream.DreamManager.wake(nearbyPlayer,
                                com.somnium.mod.sanity.SanityManager.DreamOutcome.WOKE_EARLY);
                            nearbyPlayer.method_7353(net.minecraft.class_2561.method_43470("§eЗвон колокола разбудил вас!"), false);
                        }
                    }
                }
            }

            return net.minecraft.class_1269.field_5811;
        });

        LOGGER.info("[Somnium] Инициализация завершена. Сладких снов.");
    }
}
