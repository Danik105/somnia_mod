package com.somnium.mod.advancement;

import com.google.gson.JsonObject;
import com.somnium.mod.SomniumMod;
import net.minecraft.class_195;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;

/**
 * Критерий достижения "Первое сноведение" - срабатывает при первом входе в любой сон.
 */
public class FirstDreamCriterion extends class_4558<FirstDreamCriterion.Conditions> {

    @Override
    protected Conditions method_27854(JsonObject obj, class_5258 playerPredicate, class_5257 predicateDeserializer) {
        return new Conditions(method_794(), playerPredicate);
    }

    public void trigger(class_3222 player) {
        this.method_22510(player, conditions -> true);
    }

    public static class Conditions extends class_195 {
        public Conditions(class_2960 id, class_5258 player) {
            super(id, player);
        }
    }

    @Override
    public class_2960 method_794() {
        return SomniumMod.id("first_dream");
    }
}
