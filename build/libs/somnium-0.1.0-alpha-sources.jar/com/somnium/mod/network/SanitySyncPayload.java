package com.somnium.mod.network;

import com.somnium.mod.SomniumMod;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * Синхронизирует текущее значение рассудка на клиент для отрисовки HUD.
 */
public class SanitySyncPayload {
    public static final class_2960 ID = new class_2960(SomniumMod.MOD_ID, "sanity_sync");

    public static void sendTo(class_3222 player, float sanity) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeFloat(sanity);
        ServerPlayNetworking.send(player, ID, buf);
    }
}
