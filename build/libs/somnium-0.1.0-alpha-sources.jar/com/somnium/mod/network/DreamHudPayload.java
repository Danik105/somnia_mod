package com.somnium.mod.network;

import com.somnium.mod.SomniumMod;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * ИСПРАВЛЕНИЕ ("задание сна непонятно и быстро пропадает"): раньше цель сна показывалась
 * только один раз через ванильный TitleS2CPacket/SubtitleS2CPacket в DreamManager#sendDreamTitle —
 * у него ЖЁСТКО заданное время жизни (fade-in 10 + stay 60 + fade-out 20 = 90 тиков, ~4.5 секунды),
 * после чего текст пропадает НАВСЕГДА, даже если игрок не успел прочитать. Этот пакет решает задачу
 * иначе: клиент запоминает последнее полученное состояние и рисует ПОСТОЯННЫЙ HUD (см.
 * DreamObjectiveHudRenderer), который висит на экране всё время, пока сон активен — заголовок,
 * цель и полоса оставшегося времени сна, а не мгновенно исчезающий тайтл.
 */
public class DreamHudPayload {
    public static final class_2960 ID = new class_2960(SomniumMod.MOD_ID, "dream_hud");

    public static void sendActive(class_3222 player, String dreamNameKey, String objectiveText, int remainingTicks, int totalTicks) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeBoolean(true);
        buf.method_10814(dreamNameKey);
        buf.method_10814(objectiveText);
        buf.method_10804(remainingTicks);
        buf.method_10804(totalTicks);
        ServerPlayNetworking.send(player, ID, buf);
    }

    public static void sendInactive(class_3222 player) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeBoolean(false);
        buf.method_10814("");
        buf.method_10814("");
        buf.method_10804(0);
        buf.method_10804(0);
        ServerPlayNetworking.send(player, ID, buf);
    }
}
