package com.somnium.mod.client;

import com.somnium.mod.entity.nightmare.*;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_572;
import net.minecraft.class_927;

/**
 * Placeholder рендерер для монстров-кошмаров — использует ванильные текстуры зомби/скелетов
 * до появления кастомных моделей.
 */
public class NightmarePlaceholderRenderer<T extends AbstractNightmareEntity> extends class_927<T, class_572<T>> {

    private static final class_2960 TEX_ZOMBIE          = new class_2960("minecraft", "textures/entity/zombie/zombie.png");
    private static final class_2960 TEX_DROWNED         = new class_2960("minecraft", "textures/entity/zombie/drowned.png");
    private static final class_2960 TEX_HUSK            = new class_2960("minecraft", "textures/entity/zombie/husk.png");
    private static final class_2960 TEX_ZOMBIE_VILLAGER = new class_2960("minecraft", "textures/entity/zombie_villager/zombie_villager.png");
    private static final class_2960 TEX_SKELETON        = new class_2960("minecraft", "textures/entity/skeleton/skeleton.png");
    private static final class_2960 TEX_STRAY           = new class_2960("minecraft", "textures/entity/skeleton/stray.png");
    private static final class_2960 TEX_WITHER_SKELETON = new class_2960("minecraft", "textures/entity/skeleton/wither_skeleton.png");
    private static final class_2960 TEX_PIGLIN          = new class_2960("minecraft", "textures/entity/piglin/piglin.png");
    private static final class_2960 TEX_VILLAGER        = new class_2960("minecraft", "textures/entity/villager/villager.png");

    public NightmarePlaceholderRenderer(class_5617.class_5618 context) {
        super(context, new class_572<>(context.method_32167(class_5602.field_27638)), 0.5f);
    }

    @Override
    public class_2960 getTexture(T entity) {
        // Тонущий город
        if (entity instanceof DrownedWretchEntity) return TEX_DROWNED;
        if (entity instanceof PhantomEelEntity) return TEX_STRAY;
        // Лес теней
        if (entity instanceof LurkingShadeEntity) return TEX_WITHER_SKELETON;
        // Пустошь зеркал
        if (entity instanceof MirroredDoubleEntity) return TEX_VILLAGER;
        // Шахта
        if (entity instanceof ScreamingMinerEntity) return TEX_HUSK;
        if (entity instanceof BlindBurrowerEntity) return TEX_SKELETON;
        // Кровавый пир
        if (entity instanceof FeralVillagerEntity) return TEX_ZOMBIE_VILLAGER;
        if (entity instanceof FleshGolemEntity) return TEX_PIGLIN;
        // Пустота с глазами
        if (entity instanceof WatcherEntity) return TEX_VILLAGER;
        // Сон-в-сне (босс)
        if (entity instanceof NightmareAmalgamEntity) return TEX_WITHER_SKELETON;
        return TEX_ZOMBIE;
    }
}
