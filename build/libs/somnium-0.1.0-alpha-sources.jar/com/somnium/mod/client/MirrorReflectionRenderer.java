package com.somnium.mod.client;

import com.somnium.mod.entity.nightmare.MirrorReflectionEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_572;
import net.minecraft.class_927;

/**
 * Специальный рендерер для зеркального отражения игрока.
 * Использует модель игрока и скин Стива по умолчанию.
 */
public class MirrorReflectionRenderer extends class_927<MirrorReflectionEntity, class_572<MirrorReflectionEntity>> {

    private static final class_2960 STEVE_SKIN = new class_2960("minecraft", "textures/entity/player/wide/steve.png");

    public MirrorReflectionRenderer(class_5617.class_5618 context) {
        super(context, new class_572<>(context.method_32167(class_5602.field_27577)), 0.5f);
    }

    @Override
    public class_2960 getTexture(MirrorReflectionEntity entity) {
        return STEVE_SKIN;
    }
}
