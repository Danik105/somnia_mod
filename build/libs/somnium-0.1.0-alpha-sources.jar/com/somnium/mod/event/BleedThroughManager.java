package com.somnium.mod.event;

import com.somnium.mod.dream.DreamRegistry;
import com.somnium.mod.dream.DreamType;
import com.somnium.mod.sanity.SanityData;
import com.somnium.mod.sanity.SanityManager;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

/**
 * Реализует "прорыв кошмаров в реальность" — три уровня эскалации,
 * привязанные к порогам рассудка из SanityManager.
 *
 *  < 50% (WHISPERS)  — редкие полупрозрачные "эхо", только ночью, слабый эффект
 *  < 25% (ECHOES)    — монстры ИЗ ПОСЛЕДНЕГО СНА начинают спавниться и днём
 *  < 10% (RUPTURE)   — полноценное вторжение 2-4 монстров прямо рядом с игроком
 *
 * ИСПРАВЛЕНО ("куча багов с разрывом и переходом монстров в реальность"):
 *  1. Кулдаун RUPTURE был глобальным static на весь сервер — при двух игроках
 *     в состоянии разрыва вторжение срабатывало только у первого. Теперь кулдауны
 *     (и RUPTURE, и ECHO) ведутся per-player: Map<UUID, Long>.
 *  2. Мобы спавнились в случайной точке кольца на высоте игрока — в воздухе,
 *     внутри блоков, сквозь пол. Теперь позиция валидируется: ищется твёрдая
 *     опора под ногами и свободное место для тела (по collision shape, аналог
 *     ванильного spawn placement); если точка не найдена — попытка пропускается.
 *  3. Заспавненные мобы нигде не учитывались и копились бессрочно. Теперь ведётся
 *     per-player Set<UUID> активных мобов с лимитом (выбор per-player, а не
 *     глобального лимита: на сервере один "тихий" игрок не должен съедать лимит
 *     другого, у которого разрыв). Мёртвые/деспавнувшиеся вычищаются каждый evaluate.
 *  4. tryEcho не имел кулдауна вообще — при удачных бросках спавнил несколько мобов
 *     подряд за пару секунд. Добавлен per-player кулдаун ECHO_COOLDOWN_TICKS.
 *  5. register() был пустой заглушкой — теперь подписывается на DISCONNECT и чистит
 *     per-player состояние, чтобы карты не разрастались.
 */
public final class BleedThroughManager {

    private static final Random RANDOM = new Random();

    // Антиспам: не чаще раза в ~20 секунд на игрока для RUPTURE,
    // чтобы не заваливать игрока монстрами каждый тик.
    private static final long RUPTURE_COOLDOWN_TICKS = 400L;

    // Минимальный интервал между "эхо"-спавнами (~5 секунд): без него при шансе
    // 2%/сек возможны серии из 2-3 мобов подряд за несколько секунд.
    private static final long ECHO_COOLDOWN_TICKS = 100L;

    // Максимум одновременно живых bleed-through мобов НА ИГРОКА. Сверх лимита новые
    // не спавнятся, пока старые не умрут или не деспавнятся. 4 — достаточно для
    // ощущения вторжения (RUPTURE ставит 2-4 сразу), но не превращает мир в ферму.
    private static final int MAX_ACTIVE_MOBS_PER_PLAYER = 4;

    // Сколько случайных точек кольца пробуем, прежде чем признать попытку спавна неудачной.
    private static final int SPAWN_POSITION_ATTEMPTS = 8;
    // На сколько блоков вниз от уровня игрока ищем твёрдую поверхность.
    private static final int GROUND_SCAN_DEPTH = 10;

    // Per-player кулдауны (исправление п.1 — раньше был один глобальный static long).
    private static final Map<UUID, Long> LAST_RUPTURE_TICK = new HashMap<>();
    private static final Map<UUID, Long> LAST_ECHO_TICK = new HashMap<>();

    // Per-player трекинг живых bleed-through мобов (исправление п.3).
    private static final Map<UUID, Set<UUID>> ACTIVE_MOBS = new HashMap<>();

    private BleedThroughManager() {}

    public static void register() {
        // ИСПРАВЛЕНО (п.5 — пустая заглушка): чистим per-player состояние при выходе
        // игрока, иначе карты кулдаунов/трекинга росли бы бесконечно.
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID id = handler.field_14140.method_5667();
            LAST_RUPTURE_TICK.remove(id);
            LAST_ECHO_TICK.remove(id);
            ACTIVE_MOBS.remove(id);
        });
    }

    public static void evaluate(class_3222 player, SanityData data) {
        float sanity = data.getSanity();
        class_3218 world = (class_3218) player.method_5770();

        // Вызывается раз в секунду на игрока — заодно вычищаем из трекинга мёртвых
        // и деспавнувшихся мобов, чтобы лимит отражал реальность.
        pruneTrackedMobs(world, player.method_5667());

        // Лимит достигнут — не спавним новых, пока старые живы (исправление п.3).
        if (countActive(player.method_5667()) >= MAX_ACTIVE_MOBS_PER_PLAYER) return;

        if (sanity <= SanityManager.THRESHOLD_RUPTURE) {
            tryRupture(player, world, data);
        } else if (sanity <= SanityManager.THRESHOLD_ECHOES) {
            tryEcho(player, world, data, 0.02f); // ~2% шанс за тик проверки (раз в сек)
        } else if (sanity <= SanityManager.THRESHOLD_WHISPERS) {
            if (world.method_23886()) {
                tryEcho(player, world, data, 0.005f); // редко, только ночью
            }
        }
    }

    private static void tryEcho(class_3222 player, class_3218 world, SanityData data, float chance) {
        long now = world.method_8503().method_3780();
        // ИСПРАВЛЕНО (п.4): per-player кулдаун между эхо-спавнами.
        if (now - LAST_ECHO_TICK.getOrDefault(player.method_5667(), -ECHO_COOLDOWN_TICKS) < ECHO_COOLDOWN_TICKS) return;
        if (RANDOM.nextFloat() > chance) return;

        class_2960 dreamId = class_2960.method_12829(
                data.getLastDreamId().isEmpty() ? "somnium:shadow_forest" : data.getLastDreamId());
        DreamType dream = DreamRegistry.get(dreamId);
        if (dream == null || dream.monsterEntityIds().isEmpty()) return;

        // Кулдаун отсчитываем только от УСПЕШНОГО спавна — если позицию найти не
        // удалось, следующая попытка будет уже на следующем тике, а не через 5 секунд.
        if (spawnMonsterNear(world, player, pickRandom(dream.monsterEntityIds()))) {
            LAST_ECHO_TICK.put(player.method_5667(), now);
        }
    }

    private static void tryRupture(class_3222 player, class_3218 world, SanityData data) {
        long now = world.method_8503().method_3780();
        // ИСПРАВЛЕНО (п.1): кулдаун per-player, а не глобальный на весь сервер.
        if (now - LAST_RUPTURE_TICK.getOrDefault(player.method_5667(), -RUPTURE_COOLDOWN_TICKS) < RUPTURE_COOLDOWN_TICKS) return;

        class_2960 dreamId = class_2960.method_12829(
                data.getLastDreamId().isEmpty() ? "somnium:shadow_forest" : data.getLastDreamId());
        DreamType dream = DreamRegistry.get(dreamId);
        if (dream == null || dream.monsterEntityIds().isEmpty()) return;

        // Не превышаем per-player лимит даже во время вторжения.
        int freeSlots = MAX_ACTIVE_MOBS_PER_PLAYER - countActive(player.method_5667());
        int count = Math.min(2 + RANDOM.nextInt(3), freeSlots); // 2-4 монстра, но не выше лимита

        int spawned = 0;
        for (int i = 0; i < count; i++) {
            if (spawnMonsterNear(world, player, pickRandom(dream.monsterEntityIds()))) {
                spawned++;
            }
        }
        if (spawned == 0) return; // ни одной валидной позиции — не тратим кулдаун и не пугаем игрока

        LAST_RUPTURE_TICK.put(player.method_5667(), now);

        player.method_7353(net.minecraft.class_2561.method_43471("somnium.warning.rupture_event"), true);
        // ДОБАВЛЕНО: раньше ModSounds.RUPTURE_STINGER был объявлен, но нигде не вызывался —
        // прорыв кошмаров в реальность происходил абсолютно бесшумно.
        player.method_5783(
                com.somnium.mod.registry.ModSounds.RUPTURE_STINGER,
                1.0f,
                1.0f);
        // TODO: визуальный эффект "трещины в реальности" (партиклы/шейдер-оверлей) через клиентский payload
        // TODO: временно подавить ванильный спавн мобов рядом с игроком (MobSpawnerEvents.CAN_SPAWN)
    }

    /**
     * Спавнит одного моба рядом с игроком на ВАЛИДНОЙ позиции (исправление п.2).
     * Возвращает true, если моб реально появился в мире.
     */
    private static boolean spawnMonsterNear(class_3218 world, class_3222 player, class_2960 entityId) {
        // Тот же баг, что был в DreamManager#spawnOne: Registries.ENTITY_TYPE — DefaultedRegistry
        // (дефолт minecraft:pig), поэтому .get() никогда не вернёт null для неизвестного id.
        var maybeType = class_7923.field_41177.method_17966(entityId);
        if (maybeType.isEmpty()) return false;
        class_1299<?> type = maybeType.get();

        class_2338 pos = findSpawnPos(world, player.method_24515());
        if (pos == null) return false; // валидной точки в радиусе нет — пропускаем попытку в этом тике

        var entity = type.method_5883(world);
        if (!(entity instanceof class_1308 mob)) return false;

        mob.method_5725(pos, player.method_36454(), 0);
        if (!world.method_8649(mob)) return false;

        ACTIVE_MOBS.computeIfAbsent(player.method_5667(), k -> new HashSet<>()).add(mob.method_5667());
        return true;
    }

    /**
     * Ищет безопасную точку спавна в кольце 4-8 блоков от игрока (исправление п.2):
     *  - под ногами твёрдая опора (непустая collision shape — аналог ванильного
     *    spawn placement, моб не должен появляться в воздухе и падать);
     *  - блоки на уровне ног и головы свободны (моб не застревает в стене/полу;
     *    трава/факелы без коллизии допустимы, как и в ванилле).
     * Возвращает null, если за SPAWN_POSITION_ATTEMPTS попыток ничего не нашлось.
     */
    private static class_2338 findSpawnPos(class_3218 world, class_2338 center) {
        for (int attempt = 0; attempt < SPAWN_POSITION_ATTEMPTS; attempt++) {
            double angle = RANDOM.nextDouble() * Math.PI * 2;
            double dist = 4 + RANDOM.nextDouble() * 4;
            int x = center.method_10263() + (int) Math.round(Math.cos(angle) * dist);
            int z = center.method_10260() + (int) Math.round(Math.sin(angle) * dist);

            for (int y = center.method_10264() + 1; y >= center.method_10264() - GROUND_SCAN_DEPTH; y--) {
                class_2338 feet = new class_2338(x, y, z);
                if (!world.method_8320(feet).method_26220(world, feet).method_1110()) continue;
                if (!world.method_8320(feet.method_10084()).method_26220(world, feet.method_10084()).method_1110()) continue;
                if (world.method_8320(feet.method_10074()).method_26220(world, feet.method_10074()).method_1110()) continue;
                return feet;
            }
        }
        return null;
    }

    /** Убирает из трекинга мобов, которые умерли или деспавнулись (выгрузка чанка). */
    private static void pruneTrackedMobs(class_3218 world, UUID playerId) {
        Set<UUID> tracked = ACTIVE_MOBS.get(playerId);
        if (tracked == null || tracked.isEmpty()) return;
        tracked.removeIf(id -> {
            var entity = world.method_14190(id);
            return entity == null || !entity.method_5805();
        });
        if (tracked.isEmpty()) {
            ACTIVE_MOBS.remove(playerId);
        }
    }

    private static int countActive(UUID playerId) {
        Set<UUID> tracked = ACTIVE_MOBS.get(playerId);
        return tracked == null ? 0 : tracked.size();
    }

    private static class_2960 pickRandom(List<class_2960> list) {
        return list.get(RANDOM.nextInt(list.size()));
    }
}
