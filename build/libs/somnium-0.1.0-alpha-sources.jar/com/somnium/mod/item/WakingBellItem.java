package com.somnium.mod.item;

import com.somnium.mod.dream.DreamManager;
import com.somnium.mod.sanity.SanityManager;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3419;

/**
 * ДОБАВЛЕНО ("предметов нет"): Колокол Пробуждения — крафтуемый расходник (Эссенция Кошмара +
 * золотой слиток), который у игрока и раньше формально не было причины держать в инвентаре сна:
 * снимок инвентаря при входе в сон (см. DreamManager#snapshotAndClearInventory) очищает основной
 * инвентарь ПОЛНОСТЬЮ, так что предмет нужно держать не физически с собой в кармане, а как
 * "аварийный выход" — колокол можно использовать только пока сон активен: одно нажатие ПКМ сразу
 * будит игрока (DreamOutcome.WOKE_EARLY — небольшая награда рассудка, меньше полного выполнения
 * цели, но лучше, чем ждать таймаута или рисковать умереть). До этого у игрока не было НИКАКОГО
 * способа выйти из сна раньше времени вручную — либо ждать таймер, либо использовать
 * REACH_DOOR/BOSS_KILL/COLLECT_ITEMS цель (см. DreamObjectiveType), либо умереть (со штрафом).
 */
public class WakingBellItem extends class_1792 {

    public WakingBellItem(class_1793 settings) {
        super(settings);
    }

    // ИСПРАВЛЕНО ПО ОШИБКЕ СБОРКИ: TypedActionResult<ItemStack> в вашей версии API (26.1) не
    // существует — Item#use() здесь возвращает простой ActionResult, а изменения ItemStack
    // делаются прямо на объекте, который вернул getStackInHand() (это та же ссылка, что лежит
    // в инвентаре, так что decrement() ниже сразу отражается на реальном стеке игрока).
    @Override
    public net.minecraft.class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (world.method_8608() || !(user instanceof class_3222 serverPlayer)) {
            return net.minecraft.class_1271.method_22430(stack);
        }

        if (!DreamManager.isDreaming(serverPlayer.method_5667())) {
            serverPlayer.method_7353(
                    net.minecraft.class_2561.method_43471("somnium.item.waking_bell.not_dreaming"), true);
            return net.minecraft.class_1271.method_22431(stack);
        }

        world.method_8396(null, serverPlayer.method_24515(),
                com.somnium.mod.registry.ModSounds.DREAM_WAKE, class_3419.field_15248, 1.0f, 1.4f);
        DreamManager.wake(serverPlayer, SanityManager.DreamOutcome.WOKE_EARLY);

        if (!serverPlayer.method_31549().field_7477) {
            stack.method_7934(1);
        }
        return net.minecraft.class_1271.method_29237(stack, world.method_8608());
    }
}