package com.somnium.mod.registry;

import com.somnium.mod.SomniumMod;
import com.somnium.mod.entity.SleepingBodyEntity;
import com.somnium.mod.entity.nightmare.*;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Регистрация всех сущностей-кошмаров (7 по числу снов + Phantom Eel как второй монстр
 * "Тонущего города" + Nightmare Amalgam как босс "Сна-в-сне" = 10 штук).
 * Модели/текстуры/анимации — отдельная задача клиентского модуля
 * (assets/somnium/models/entity/*, textures/entity/*, а также
 * EntityRendererRegistry в client-модуле, см. SomniumClient.java).
 */
public final class ModEntities {

    private ModEntities() {}

    public static final class_1299<DrownedWretchEntity> DROWNED_WRETCH = register(
            "drowned_wretch", DrownedWretchEntity::new, class_1311.field_6302, 0.6f, 1.95f);

    public static final class_1299<LurkingShadeEntity> LURKING_SHADE = register(
            "lurking_shade", LurkingShadeEntity::new, class_1311.field_6302, 0.6f, 2.2f);

    public static final class_1299<MirroredDoubleEntity> MIRRORED_DOUBLE = register(
            "mirrored_double", MirroredDoubleEntity::new, class_1311.field_6302, 0.6f, 1.95f);

    public static final class_1299<ScreamingMinerEntity> SCREAMING_MINER = register(
            "screaming_miner", ScreamingMinerEntity::new, class_1311.field_6302, 0.6f, 1.95f);

    public static final class_1299<BlindBurrowerEntity> BLIND_BURROWER = register(
            "blind_burrower", BlindBurrowerEntity::new, class_1311.field_6302, 1.2f, 1.4f);

    public static final class_1299<FeralVillagerEntity> FERAL_VILLAGER = register(
            "feral_villager", FeralVillagerEntity::new, class_1311.field_6302, 0.6f, 1.95f);

    public static final class_1299<FleshGolemEntity> FLESH_GOLEM = register(
            "flesh_golem", FleshGolemEntity::new, class_1311.field_6302, 1.4f, 2.9f);

    public static final class_1299<WatcherEntity> WATCHER = register(
            "watcher", WatcherEntity::new, class_1311.field_6302, 1.0f, 2.6f);

    public static final class_1299<NightmareAmalgamEntity> NIGHTMARE_AMALGAM = register(
            "nightmare_amalgam", NightmareAmalgamEntity::new, class_1311.field_6302, 1.8f, 3.4f);

    // ДОБАВЛЕНО: "phantom_eel" был упомянут в DreamRegistry как мёртвая ссылка на никогда не
    // зарегистрированную сущность (drowning_city ссылался на id, которого не существовало в этом
    // реестре — Registries.ENTITY_TYPE тихо подставлял свинью вместо предупреждения, см. старый
    // комментарий в DreamRegistry). Теперь зарегистрирован по-настоящему.
    public static final class_1299<PhantomEelEntity> PHANTOM_EEL = register(
            "phantom_eel", PhantomEelEntity::new, class_1311.field_6300, 0.5f, 0.5f);

    // ДОБАВЛЕНО (моб-наблюдатель): Stalker с механикой Weeping Angel - замирает когда игрок
    // смотрит на него, быстро приближается когда не смотрит.
    public static final class_1299<StalkerEntity> STALKER = register(
            "stalker", StalkerEntity::new, class_1311.field_6302, 0.6f, 1.95f);

    // Зеркальное отражение игрока в сне "Зеркальная комната"
    public static final class_1299<MirrorReflectionEntity> MIRROR_REFLECTION = register(
            "mirror_reflection", MirrorReflectionEntity::new, class_1311.field_6302, 0.6f, 1.95f);

    // ДОБАВЛЕНО (мультиплеер): спящее тело игрока, которое остаётся в реальном мире,
    // пока сам игрок находится в измерении сна. Другие игроки видят это тело лежащим в кровати.
    public static final class_1299<SleepingBodyEntity> SLEEPING_BODY = class_2378.method_39197(
            class_7923.field_41177,
            class_5321.method_29179(class_7924.field_41266, SomniumMod.id("sleeping_body")),
            class_1299.class_1300.method_5903(SleepingBodyEntity::new, class_1311.field_17715)
                    .method_17687(0.6f, 0.6f)
                    .method_5905("sleeping_body")
    );

    private static <T extends net.minecraft.class_1588> class_1299<T> register(
            String path, class_1299.class_4049<T> factory, class_1311 group, float width, float height) {
        class_5321<class_1299<?>> key = class_5321.method_29179(class_7924.field_41266, SomniumMod.id(path));
        class_1299<T> type = class_2378.method_39197(
                class_7923.field_41177,
                key,
                class_1299.class_1300.method_5903(factory, group)
                        .method_17687(width, height)
                        .method_5905(path)
        );
        return type;
    }

    public static void register() {
        // Метод-триггер для загрузки класса (гарантирует инициализацию static полей выше)
        SomniumMod.LOGGER.info("[Somnium] Зарегистрировано 12 сущностей-кошмаров + 1 служебная (sleeping_body)");
    }

    /** Регистрация дефолтных атрибутов — вызывается в ModInitializer ДО первого спавна. */
    public static void registerAttributes() {
        FabricDefaultAttributeRegistry.register(DROWNED_WRETCH, DrownedWretchEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(LURKING_SHADE, LurkingShadeEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MIRRORED_DOUBLE, MirroredDoubleEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(SCREAMING_MINER, ScreamingMinerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(BLIND_BURROWER, BlindBurrowerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(FERAL_VILLAGER, FeralVillagerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(FLESH_GOLEM, FleshGolemEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(WATCHER, WatcherEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(NIGHTMARE_AMALGAM, NightmareAmalgamEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(PHANTOM_EEL, PhantomEelEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(STALKER, StalkerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MIRROR_REFLECTION, MirrorReflectionEntity.createMirrorReflectionAttributes());
        FabricDefaultAttributeRegistry.register(SLEEPING_BODY, SleepingBodyEntity.createSleepingBodyAttributes());
    }
}
