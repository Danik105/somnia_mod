package com.somnium.mod.registry;

import com.somnium.mod.SomniumMod;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Предметы мода.
 *  - CLARITY_SHARD ("Осколок Ясности") — восстанавливает рассудок при использовании,
 *    основная награда за успешное прохождение снов; также цель сбора в сне "Кровавый пир"
 *    (см. DreamRegistry, DreamObjectiveType.COLLECT_ITEMS).
 *  - DREAM_CATCHER ("Ловец Снов") — ИСПРАВЛЕНО ("предметов нет" / предмет ничего не делал):
 *    раньше существовал только как запись в реестре без единого эффекта. Теперь реально снижает
 *    скорость падения рассудка, если лежит у игрока в инвентаре — см. SanityManager#computeDrainRate.
 *  - NIGHTMARE_ESSENCE ("Эссенция Кошмара") — ДОБАВЛЕНО: крафтовый ресурс, роняется любым
 *    монстром-кошмаром при смерти от руки игрока (см. AbstractNightmareEntity#onDeath). Раньше
 *    ни один монстр ничего не ронял — это был единственный источник материалов мода.
 *  - WAKING_BELL ("Колокол Пробуждения") — ДОБАВЛЕНО: расходник, позволяющий добровольно и
 *    немедленно проснуться посреди сна (см. WakingBellItem) — раньше у игрока не было НИКАКОГО
 *    способа выйти из сна раньше времени вручную, кроме риска умереть или ждать таймер.
 */
public final class ModItems {

    private ModItems() {}

    public static final class_1792 CLARITY_SHARD = register("clarity_shard",
            settings -> new class_1792(settings.method_7889(16)));

    public static final class_1792 DREAM_CATCHER = register("dream_catcher",
            settings -> new class_1792(settings.method_7889(1)));

    public static final class_1792 NIGHTMARE_ESSENCE = register("nightmare_essence",
            settings -> new class_1792(settings.method_7889(64)));

    public static final class_1792 WAKING_BELL = register("waking_bell",
            settings -> new com.somnium.mod.item.WakingBellItem(settings.method_7889(4)));

    private static class_1792 register(String path, java.util.function.Function<class_1792.class_1793, class_1792> factory) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, SomniumMod.id(path));
        return class_2378.method_39197(class_7923.field_41178, key, factory.apply(new class_1792.class_1793()));
    }

    public static void register() {
        SomniumMod.LOGGER.info("[Somnium] Предметы зарегистрированы");
    }
}
