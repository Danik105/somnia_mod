package com.somnium.mod.registry;

import com.somnium.mod.SomniumMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * ИСПРАВЛЕНО ("нет предметов из мода"): ModItems.CLARITY_SHARD и ModItems.DREAM_CATCHER
 * регистрировались в Registries.ITEM, но НИ В ОДНУ ItemGroup (вкладку творческого режима)
 * никогда не добавлялись — из-за этого предметы физически существовали (их можно было
 * выдать через /give somnium:clarity_shard), но игрок никогда не видел их в инвентаре
 * творческого режима и мог решить, что предметов мода вообще нет.
 * Обратите внимание: перевод "itemGroup.somnium" уже был подготовлен в lang-файлах —
 * не хватало только этого класса и вызова register() из SomniumMod#onInitialize.
 */
public final class ModItemGroups {

    private ModItemGroups() {}

    public static final class_5321<class_1761> SOMNIUM_GROUP_KEY =
            class_5321.method_29179(class_7924.field_44688, SomniumMod.id("somnium"));

    public static final class_1761 SOMNIUM_GROUP = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModItems.CLARITY_SHARD))
            .method_47321(class_2561.method_43471("itemGroup.somnium"))
            .method_47317((context, entries) -> {
                entries.method_45421(ModItems.CLARITY_SHARD);
                entries.method_45421(ModItems.DREAM_CATCHER);
                // ДОБАВЛЕНО: новые предметы (см. ModItems) — раньше вкладка содержала только 2
                // из 2 существовавших предметов; теперь добавлены и оба новых.
                entries.method_45421(ModItems.NIGHTMARE_ESSENCE);
                entries.method_45421(ModItems.WAKING_BELL);
            })
            .method_47324();

    public static void register() {
        class_2378.method_39197(class_7923.field_44687, SOMNIUM_GROUP_KEY, SOMNIUM_GROUP);
        SomniumMod.LOGGER.info("[Somnium] Вкладка творческого режима зарегистрирована");
    }
}
