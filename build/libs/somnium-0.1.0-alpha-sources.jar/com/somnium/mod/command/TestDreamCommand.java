package com.somnium.mod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.somnium.mod.SomniumMod;
import com.somnium.mod.dream.DreamManager;
import com.somnium.mod.dream.DreamRegistry;
import com.somnium.mod.dream.DreamType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

/**
 * Команда /testdream для быстрого запуска полноценного сна (с заданием, таймером, мобами).
 * Использование: /testdream <dream_name>
 *
 * Доступные сны:
 * - drowning_city
 * - shadow_forest
 * - mirror_wastes
 * - collapsing_mine
 * - crimson_feast
 * - void_of_eyes
 * - dream_within_dream
 * - falling_planks
 */
public class TestDreamCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(class_2170.method_9247("testdream")
                .then(class_2170.method_9247("drowning_city")
                        .executes(ctx -> startDream(ctx, "drowning_city")))
                .then(class_2170.method_9247("shadow_forest")
                        .executes(ctx -> startDream(ctx, "shadow_forest")))
                .then(class_2170.method_9247("mirror_wastes")
                        .executes(ctx -> startDream(ctx, "mirror_wastes")))
                .then(class_2170.method_9247("collapsing_mine")
                        .executes(ctx -> startDream(ctx, "collapsing_mine")))
                .then(class_2170.method_9247("crimson_feast")
                        .executes(ctx -> startDream(ctx, "crimson_feast")))
                .then(class_2170.method_9247("void_of_eyes")
                        .executes(ctx -> startDream(ctx, "void_of_eyes")))
                .then(class_2170.method_9247("dream_within_dream")
                        .executes(ctx -> startDream(ctx, "dream_within_dream")))
                .then(class_2170.method_9247("falling_planks")
                        .executes(ctx -> startDream(ctx, "falling_planks")))
                .then(class_2170.method_9247("mirror_room")
                        .executes(ctx -> startDream(ctx, "mirror_room")))
        );
    }

    private static int startDream(CommandContext<class_2168> ctx, String dreamName) {
        class_2168 source = ctx.getSource();
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("Эту команду может использовать только игрок"));
            return 0;
        }

        class_2960 dreamId = SomniumMod.id(dreamName);
        DreamType dreamType = DreamRegistry.get(dreamId);

        if (dreamType == null) {
            source.method_9213(class_2561.method_43470("Неизвестный сон: " + dreamName));
            return 0;
        }

        // Запускаем полноценный сон через DreamManager (как при обычном засыпании)
        // Это включает: телепортацию, спавн мобов, установку цели, таймер, эффекты и т.д.
        DreamManager.enterDreamDirectly(player, dreamType);

        source.method_9226(() -> class_2561.method_43470("§aЗапуск сна: §f" + dreamName), false);
        return 1;
    }
}
