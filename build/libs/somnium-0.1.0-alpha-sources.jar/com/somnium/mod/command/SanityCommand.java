package com.somnium.mod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.somnium.mod.network.SanitySyncPayload;
import com.somnium.mod.sanity.SanityData;
import com.somnium.mod.sanity.SanityManager;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_7157;

/**
 * ДОБАВЛЕНО ("добавь команды, чтобы влиять на шкалу рассудка"): команда /sanity
 * для отладки и тестирования системы рассудка.
 *
 * Использование:
 *  /sanity get [игрок]        — показать текущее значение
 *  /sanity set <0-100> [игрок] — установить значение
 *  /sanity add <дельта> [игрок] — прибавить/отнять (отрицательное число)
 *
 * Если игрок не указан — применяется к тому, кто ввёл команду.
 * После изменения значение сразу синхронизируется на клиент (HUD обновляется мгновенно,
 * не дожидаясь ближайшего секундного тика SanityManager).
 */
public class SanityCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(class_2170.method_9247("sanity")
                .then(class_2170.method_9247("get")
                        .executes(ctx -> getSanity(ctx, null))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(ctx -> getSanity(ctx, class_2186.method_9315(ctx, "player")))))
                .then(class_2170.method_9247("set")
                        .then(class_2170.method_9244("value", FloatArgumentType.floatArg(0.0f, 100.0f))
                                .executes(ctx -> setSanity(ctx, FloatArgumentType.getFloat(ctx, "value"), null))
                                .then(class_2170.method_9244("player", class_2186.method_9305())
                                        .executes(ctx -> setSanity(ctx, FloatArgumentType.getFloat(ctx, "value"), class_2186.method_9315(ctx, "player"))))))
                .then(class_2170.method_9247("add")
                        .then(class_2170.method_9244("delta", FloatArgumentType.floatArg(-100.0f, 100.0f))
                                .executes(ctx -> addSanity(ctx, FloatArgumentType.getFloat(ctx, "delta"), null))
                                .then(class_2170.method_9244("player", class_2186.method_9305())
                                        .executes(ctx -> addSanity(ctx, FloatArgumentType.getFloat(ctx, "delta"), class_2186.method_9315(ctx, "player"))))))
        );
    }

    private static class_3222 resolveTarget(CommandContext<class_2168> ctx, class_3222 explicit) {
        return explicit != null ? explicit : ctx.getSource().method_44023();
    }

    private static int getSanity(CommandContext<class_2168> ctx, class_3222 explicit) {
        class_3222 target = resolveTarget(ctx, explicit);
        if (target == null) {
            ctx.getSource().method_9213(class_2561.method_43470("Эту команду может использовать только игрок"));
            return 0;
        }
        float value = SanityManager.get(target).getSanity();
        final String name = target.method_5477().getString();
        ctx.getSource().method_9226(() -> class_2561.method_43470("§bРассудок §f" + name + "§b: §f" + String.format("%.1f", value)), false);
        return 1;
    }

    private static int setSanity(CommandContext<class_2168> ctx, float value, class_3222 explicit) {
        class_3222 target = resolveTarget(ctx, explicit);
        if (target == null) {
            ctx.getSource().method_9213(class_2561.method_43470("Эту команду может использовать только игрок"));
            return 0;
        }
        SanityData data = SanityManager.get(target);
        data.setSanity(value);
        SanitySyncPayload.sendTo(target, data.getSanity());
        final String name = target.method_5477().getString();
        ctx.getSource().method_9226(() -> class_2561.method_43470("§aРассудок §f" + name + "§a установлен: §f" + String.format("%.1f", data.getSanity())), false);
        return 1;
    }

    private static int addSanity(CommandContext<class_2168> ctx, float delta, class_3222 explicit) {
        class_3222 target = resolveTarget(ctx, explicit);
        if (target == null) {
            ctx.getSource().method_9213(class_2561.method_43470("Эту команду может использовать только игрок"));
            return 0;
        }
        SanityData data = SanityManager.get(target);
        data.addSanity(delta);
        SanitySyncPayload.sendTo(target, data.getSanity());
        final String name = target.method_5477().getString();
        ctx.getSource().method_9226(() -> class_2561.method_43470("§aРассудок §f" + name + "§a изменён: §f" + String.format("%.1f", data.getSanity())), false);
        return 1;
    }
}
