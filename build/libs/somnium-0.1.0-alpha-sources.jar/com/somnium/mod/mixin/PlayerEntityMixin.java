package com.somnium.mod.mixin;

import com.mojang.datafixers.util.Either;
import com.somnium.mod.SomniumMod;
import com.somnium.mod.dream.DreamManager;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3902;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Заменяет прежний подход через UseBlockCallback (SleepEventHandler, теперь удалён):
 * тот вариант проверял isSleeping() на СЛЕДУЮЩИЙ тик после клика по кровати, что могло
 * пропустить кейсы или сработать при неудачной попытке лечь (монстры рядом, не ночь и т.д.),
 * потому что сама проверка "разрешено ли лечь" происходит в ванильном коде ПОСЛЕ клика.
 *
 * В 1.21.11 метода PlayerEntity#sleep(BlockPos) больше нет — вместо него
 * PlayerEntity#trySleep(BlockPos) одновременно и пытается уложить игрока, и возвращает
 * результат: Either<SleepFailureReason, Unit>. Left = не удалось лечь (причина отказа),
 * Right = удалось. Перехватываем RETURN и реагируем только на успех.
 */
@Mixin(class_1657.class)
public abstract class PlayerEntityMixin {

    @Inject(method = "trySleep", at = @At("RETURN"))
    private void somnium$onSleep(class_2338 pos, CallbackInfoReturnable<Either<class_1657.class_1658, class_3902>> cir) {
        class_1657 self = (class_1657) (Object) this;

        if (self.method_5770().method_8608()) return;
        if (!(self instanceof class_3222 serverPlayer)) return;

        Either<class_1657.class_1658, class_3902> result = cir.getReturnValue();
        if (result.right().isEmpty()) return; // не удалось лечь — Left(SleepFailureReason)

        SomniumMod.LOGGER.debug("[Somnium] Игрок {} лёг спать — переход в сон через {} тиков", serverPlayer.method_5477().getString(), DreamManager.SLEEP_TRANSITION_TICKS);
        DreamManager.scheduleDream(serverPlayer);
    }
}
