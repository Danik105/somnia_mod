package com.somnium.mod.mixin;

import com.somnium.mod.dream.DreamManager;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * "Смерть" внутри сна не должна быть настоящей смертью — по замыслу мода игрок должен
 * резко ПРОСНУТЬСЯ (вернуться в реальный мир), а не увидеть экран смерти/потерять предметы.
 *
 * Поэтому здесь мы ПОЛНОСТЬЮ ОТМЕНЯЕМ ci.cancel() ванильную обработку смерти, если игрок
 * находится в активном сне, и вместо неё вызываем DreamManager.onDeathInDream(), который
 * восстанавливает здоровье и телепортирует игрока обратно (см. DreamManager#onDeathInDream).
 */
@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin {

    @Inject(method = "onDeath", at = @At("HEAD"), cancellable = true)
    private void somnium$onDeath(net.minecraft.class_1282 source, CallbackInfo ci) {
        class_3222 self = (class_3222) (Object) this;
        if (DreamManager.isDreaming(self.method_5667())) {
            ci.cancel();
            DreamManager.onDeathInDream(self);
        }
    }

    /**
     * ИСПРАВЛЕНИЕ (мгновенная "смерть" от падения сразу при входе в сон): смерть выше
     * отменяется, но сам урон (и тряска экрана/красная вспышка/звук) уже успевает
     * произойти к моменту onDeath. В коротком окне после телепортации в сон/обратно
     * (см. DreamManager#grantLandingImmunity) блокируем любой урон целиком — этого
     * времени достаточно, чтобы игрок гарантированно "приземлился", а не проходит
     * насквозь через реальный игровой процесс сна.
     */
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void somnium$onDamage(net.minecraft.class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        class_3222 self = (class_3222) (Object) this;
        if (self.method_37908() instanceof class_3218 world) {
            MinecraftServer server = world.method_8503();
            if (server != null && DreamManager.isLandingImmune(self.method_5667(), server.method_3780())) {
                cir.setReturnValue(false);
            }
        }
    }
}
