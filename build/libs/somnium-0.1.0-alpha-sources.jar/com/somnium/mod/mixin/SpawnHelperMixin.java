package com.somnium.mod.mixin;

import com.somnium.mod.dimension.ModDimensions;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ИСПРАВЛЕНИЕ: ванильные мобы (пауки, скелеты) всё равно спавнятся в измерениях снов,
 * несмотря на spawn_overrides в JSON. Этот миксин полностью блокирует естественный спавн
 * мобов в измерениях снов — там должны быть только наши кошмары (AbstractNightmareEntity),
 * которых мы спавним вручную через DreamManager.
 */
@Mixin(class_1948.class)
public class SpawnHelperMixin {

    @Inject(
            method = "spawnEntitiesInChunk",
            at = @At("HEAD"),
            cancellable = true
    )
    private static void somnium$cancelSpawnInDreamDimensions(
            class_1311 spawnGroup,
            class_3218 world,
            class_2818 chunk,
            class_1948.class_5261 checker,
            class_1948.class_5259 runner,
            CallbackInfo ci
    ) {
        // Если это одно из измерений снов — отменяем спавн полностью
        if (ModDimensions.isDreamDimension(world.method_27983())) {
            ci.cancel();
        }
    }
}
