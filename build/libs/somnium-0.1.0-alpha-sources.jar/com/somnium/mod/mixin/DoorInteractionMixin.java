package com.somnium.mod.mixin;

import com.somnium.mod.dream.DreamManager;
import com.somnium.mod.dream.WakeDoorTracker;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Перехватывает взаимодействие игрока с дверью (правый клик) для отслеживания
 * открытия "Двери пробуждения" в снах.
 */
@Mixin(class_2323.class)
public class DoorInteractionMixin {

    @Inject(method = "onUse", at = @At("HEAD"))
    private void somnium$onDoorInteraction(
            class_2680 state,
            class_1937 world,
            class_2338 pos,
            class_1657 player,
            class_1268 hand,
            class_3965 hit,
            CallbackInfoReturnable<class_1269> cir) {

        if (world.method_8608()) return;
        if (!(player instanceof class_3222 serverPlayer)) return;

        // Проверяем, находится ли игрок в активном сне
        if (!DreamManager.isDreaming(serverPlayer.method_5667())) return;

        // Проверяем, является ли эта дверь берёзовой (Двери пробуждения делаются из берёзы)
        if (!state.method_27852(net.minecraft.class_2246.field_10352)) return;

        // Отмечаем, что игрок открыл дверь
        WakeDoorTracker.onDoorOpened(serverPlayer.method_5667());
    }
}
