package com.somnium.mod.entity;

import com.somnium.mod.dream.DreamManager;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_5132;
import net.minecraft.server.MinecraftServer;
import java.util.Collections;
import java.util.Optional;
import java.util.UUID;

/**
 * ДОБАВЛЕНО (мультиплеер, "видел как второй всё ещё спит — моделька которая лежит"):
 * физическое тело игрока, лежащее в кровати в реальном мире, пока сам игрок находится
 * в измерении сна. Спавнится DreamManager#spawnSleepingBody при входе в сон и убирается
 * при пробуждении (DreamManager#despawnSleepingBody).
 *
 * Свойства:
 *  - неуязвима (но creative-игрок при желании может её убить — аварийная очистка);
 *  - не толкается и не двигается (NoAI по сути: AI нет уже на уровне LivingEntity);
 *  - хранит UUID владельца в DataTracker (синхронизируется клиенту для рендера скина);
 *  - самоочистка: если владелец вышел с сервера или уже не во сне (перезапуск сервера,
 *    потерянный discard), тело удаляет себя само через короткий грейс-период.
 */
public class SleepingBodyEntity extends class_1309 {

    /** UUID игрока-владельца (строкой, чтобы DataTracker умел его синхронизировать). */
    private static final class_2940<String> OWNER_UUID =
            class_2945.method_12791(SleepingBodyEntity.class, class_2943.field_13326);

    /** Грейс-период до начала самоочистки (тиков) — защита от гонки при спавне. */
    private static final int SELF_CLEAN_GRACE_TICKS = 100;

    public SleepingBodyEntity(class_1299<? extends SleepingBodyEntity> type, class_1937 world) {
        super(type, world);
        this.method_5684(true);
        this.method_5803(true);
        this.method_5875(true);
    }

    @Override
    protected void method_5693() {
        super.method_5693();
        this.field_6011.method_12784(OWNER_UUID, "");
    }

    public void setOwnerUuid(UUID uuid) {
        this.field_6011.method_12778(OWNER_UUID, uuid.toString());
    }

    public Optional<UUID> getOwnerUuid() {
        String raw = this.field_6011.method_12789(OWNER_UUID);
        if (raw == null || raw.isEmpty()) return Optional.empty();
        try {
            return Optional.of(UUID.fromString(raw));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }

    public static class_5132.class_5133 createSleepingBodyAttributes() {
        return class_1309.method_26827();
    }

    // --- "Пустое" тело: без брони, без предметов, без основной руки ---

    @Override
    public Iterable<class_1799> method_5661() {
        return Collections.emptyList();
    }

    @Override
    public class_1799 method_6118(class_1304 slot) {
        return class_1799.field_8037;
    }

    @Override
    public void method_5673(class_1304 slot, class_1799 stack) {
        // no-op: телу нечего экипировать
    }

    @Override
    public class_1306 method_6068() {
        return class_1306.field_6183;
    }

    // --- Неподвижность: тело нельзя сдвинуть с кровати ---

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public void method_6087(class_1297 entity) {
        // no-op: не отталкиваем других
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (this.method_37908().method_8608()) return;

        // Самоочистка: раз в 2 секунды после грейс-периода проверяем, что владелец
        // всё ещё на сервере и всё ещё во сне. Иначе тело удаляем — оно не должно
        // остаться "брошенным" в мире при перезапуске сервера или потерянном wake().
        if (this.field_6012 > SELF_CLEAN_GRACE_TICKS && this.field_6012 % 40 == 0) {
            Optional<UUID> owner = getOwnerUuid();
            boolean shouldDiscard;
            if (owner.isEmpty()) {
                shouldDiscard = true; // владелец неизвестен (битые NBT) — убираем
            } else {
                MinecraftServer server = this.method_5682();
                class_3222 player = server != null
                        ? server.method_3760().method_14602(owner.get())
                        : null;
                // Владелец оффлайн ИЛИ онлайн, но уже не во сне — тело больше не нужно.
                shouldDiscard = player == null || !DreamManager.isDreaming(owner.get());
            }
            if (shouldDiscard) {
                this.method_31472();
            }
        }
    }

    // --- Сохранение владельца в NBT: без этого после перезапуска сервера тело бы ---
    // --- "забыло", чьё оно, и самоочистка сработала бы только по пустому UUID. ---

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        getOwnerUuid().ifPresent(uuid -> nbt.method_25927("OwnerUuid", uuid));
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        if (nbt.method_25928("OwnerUuid")) {
            setOwnerUuid(nbt.method_25926("OwnerUuid"));
        }
    }
}
