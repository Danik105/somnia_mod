package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Flesh Golem — крупный медленный "мини-босс" сна «Кровавый пир».
 * Раз в несколько секунд бьёт по площади (эффект отбрасывания) —
 * важно не толпиться рядом.
 */
public class FleshGolemEntity extends AbstractNightmareEntity {

    private int slamCooldown = 0;

    public FleshGolemEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 60.0)
                .method_26868(class_5134.field_23719, 0.15)
                .method_26868(class_5134.field_23721, 9.0)
                .method_26868(class_5134.field_23718, 1.0);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (slamCooldown > 0) {
            slamCooldown--;
        }
        // TODO: атака по площади (AoE slam) с анимацией и отбрасыванием игроков в радиусе 4 блока,
        // перезарядка ~8 секунд (slamCooldown = 160)
    }
}
