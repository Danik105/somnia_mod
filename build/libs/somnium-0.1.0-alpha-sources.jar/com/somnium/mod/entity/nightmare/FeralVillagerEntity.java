package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Feral Villager — одичавший житель «Кровавого пира».
 * Спавнится группами (стая), становится быстрее, когда рядом ранен другой
 * Feral Villager (эффект "запаха крови" — паническая ярость стаи).
 */
public class FeralVillagerEntity extends AbstractNightmareEntity {

    public FeralVillagerEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 14.0)
                .method_26868(class_5134.field_23719, 0.27)
                .method_26868(class_5134.field_23721, 3.5);
    }

    // TODO: детектор раненых сородичей в радиусе 8 блоков -> временный баф скорости/урона
}
