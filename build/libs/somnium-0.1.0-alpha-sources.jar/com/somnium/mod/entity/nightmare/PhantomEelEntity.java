package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1347;
import net.minecraft.class_1394;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Phantom Eel — второй монстр «Тонущего города», упомянутый в комментариях DreamRegistry как
 * никогда не зарегистрированная сущность (баг, из-за которого DefaultedRegistry молча подставлял
 * свинью вместо предупреждения). Теперь зарегистрирован по-настоящему — см. ModEntities.
 *
 * Механика: в отличие от Drowned Wretch (медлительный на суше, опасный в воде), Phantom Eel
 * ПОЛНОСТЬЮ водное существо — не выходит на сушу вовсе (у него нет ходьбы), зато под водой
 * стремительно атакует из засады: ускоряется рывком, когда игрок оказывается в воде рядом,
 * и почти не показывается на поверхности.
 */
public class PhantomEelEntity extends AbstractNightmareEntity {

    private static final double AMBUSH_RANGE = 6.0;

    public PhantomEelEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 14.0)
                .method_26868(class_5134.field_23719, 0.30)
                .method_26868(class_5134.field_23721, 5.0);
    }

    @Override
    protected void method_5959() {
        // Своя, упрощённая версия набора целей предка: без сухопутного блуждания —
        // угорь целиком водный и на суше беспомощен.
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new net.minecraft.class_1366(this, 1.4, true));
        this.field_6201.method_6277(2, new class_1394(this, 1.0));
        this.field_6185.method_6277(1, new net.minecraft.class_1399(this));
        this.field_6185.method_6277(2, new net.minecraft.class_1400<>(this, class_1657.class, true));
    }

    @Override
    public void method_5773() {
        super.method_5773();
        boolean ambushReady = this.method_5799();
        this.method_5996(class_5134.field_23719)
                .method_6192(ambushReady ? 0.42 : 0.05); // почти неподвижен вне воды
    }

    @Override
    public boolean method_6094() {
        return true;
    }

    @Override
    public boolean method_5675() {
        return false;
    }
}
