package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Lurking Shade — обитатель «Бесконечного леса теней».
 * Ключевая механика: становится невидимой (эффект Invisibility), пока
 * ближайший игрок смотрит прямо на неё (угол обзора < ~30°), и снова
 * проявляется и ускоряется, когда игрок отворачивается — заставляя
 * бояться обернуться, но и не позволяя вечно "держать её на мушке".
 */
public class LurkingShadeEntity extends AbstractNightmareEntity {

    private static final double VIEW_CONE_DOT_THRESHOLD = 0.85; // ~косинус 30°

    public LurkingShadeEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 18.0)
                .method_26868(class_5134.field_23719, 0.20)
                // ИСПРАВЛЕНО (баланс): было 6.0 (3 сердца за удар) — тень невидима под взглядом
                // и быстра в темноте, поэтому ударов не избежать; 2.0 (1 сердце) оставляет
                // опасность, но перестаёт быть "несправедливой" расправой
                .method_26868(class_5134.field_23721, 2.0);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        class_1657 nearest = this.method_5770().method_18460(this, 24.0);

        // Грейс-период 12 секунд от входа в сон: тень не целится в игрока, пока он осматривается
        if (nearest instanceof net.minecraft.class_3222 spe
                && this.method_5770() instanceof net.minecraft.class_3218 serverWorld
                && com.somnium.mod.dream.DreamManager.isInDreamEntryGrace(
                        spe.method_5667(), serverWorld.method_8503().method_3780())) {
            this.method_5980(null);
        }

        boolean watched = nearest != null && isBeingWatchedBy(nearest);

        this.method_5648(!watched);
        this.method_5996(class_5134.field_23719)
                .method_6192(watched ? 0.05 : 0.32); // замирает под взглядом, иначе рвётся вперёд
    }

    @Override
    public boolean method_6121(net.minecraft.class_1297 target) {
        // Грейс-период: даже случайный контакт в первые 12 секунд сна не наносит урона
        if (target instanceof net.minecraft.class_3222 spe
                && this.method_37908() instanceof net.minecraft.class_3218 serverWorld
                && com.somnium.mod.dream.DreamManager.isInDreamEntryGrace(
                        spe.method_5667(), serverWorld.method_8503().method_3780())) {
            return false;
        }
        return super.method_6121(target);
    }

    private boolean isBeingWatchedBy(class_1657 player) {
        var lookVec = player.method_5828(1.0f).method_1029();
        var toEntity = this.method_19538().method_1020(player.method_33571()).method_1029();
        return lookVec.method_1026(toEntity) > VIEW_CONE_DOT_THRESHOLD;
    }
}
