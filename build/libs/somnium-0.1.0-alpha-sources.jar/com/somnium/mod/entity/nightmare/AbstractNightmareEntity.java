package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1366;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;

/**
 * Общий предок для всех 6-7 уникальных сущностей-кошмаров.
 * Полностью новые сущности "с нуля" (не наследуют ванильные мобы),
 * но переиспользуют ванильный набор AI-целей как отправную точку —
 * каждый наследник переопределяет initGoals() под свою уникальную механику.
 */
public abstract class AbstractNightmareEntity extends class_1588 {

    protected AbstractNightmareEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    /** Базовые атрибуты — переопределяются наследниками под конкретного монстра. */
    public static class_5132.class_5133 createNightmareAttributes() {
        return class_1588.method_26918()
                .method_26868(class_5134.field_23716, 20.0)
                .method_26868(class_5134.field_23719, 0.25)
                .method_26868(class_5134.field_23721, 4.0)
                .method_26868(class_5134.field_23717, 32.0);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1366(this, 1.0, false));
        this.field_6201.method_6277(2, new class_1394(this, 0.8));
        this.field_6201.method_6277(3, new class_1361(this, class_1657.class, 12.0f));
        this.field_6201.method_6277(4, new class_1376(this));
        this.field_6185.method_6277(1, new class_1399(this));
        this.field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
    }

    /**
     * Все монстры снов родом "не отсюда" — стоят на месте под прямыми солнечными лучами
     * гораздо хуже ванильных мобов (усиленный лор-эффект), но это переопределяется по вкусу
     * в конкретных наследниках (например, Наблюдателю (Watcher) свет не важен вовсе).
     */
    @Override
    public boolean method_6086() {
        return true;
    }

    /**
     * ДОБАВЛЕНО ("предметов нет"): раньше NIGHTMARE_ESSENCE негде было получить — не было ни
     * одного источника этого предмета в игре. Теперь любой монстр-кошмар, убитый игроком, роняет
     * 1-2 Эссенции Кошмара — основной крафтовый ресурс мода (Ловец Снов, Колокол Пробуждения).
     * Не роняет ничего при смерти НЕ от игрока (например, от игрового мира), чтобы не плодить
     * фарм через окружающую среду без риска.
     */
    // ПРОВЕРИТЬ ПРИ ПЕРВОЙ СБОРКЕ: сигнатура dropStack(ServerWorld, ItemStack) взята по аналогии
    // с тем, как в 1.21.x многим методам LivingEntity добавили явный параметр ServerWorld вместо
    // обращения к полю world напрямую (как и в остальном коде проекта, см. README про getTopY/
    // player.teleport и т.п.). Если в вашей сборке 26.1 метод называется иначе или принимает
    // другие аргументы — поправьте по автодополнению IDE/декомпилу.
    @Override
    public void method_6078(net.minecraft.class_1282 damageSource) {
        super.method_6078(damageSource);
        if (this.method_5770() instanceof net.minecraft.class_3218 serverWorld
                && damageSource.method_5529() instanceof class_1657) {
            int count = 1 + this.method_6051().method_43048(2);
            this.method_5775(new net.minecraft.class_1799(
                    com.somnium.mod.registry.ModItems.NIGHTMARE_ESSENCE, count));
        }
    }
}
