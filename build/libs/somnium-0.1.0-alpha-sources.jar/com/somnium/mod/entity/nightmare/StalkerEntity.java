package com.somnium.mod.entity.nightmare;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;

/**
 * ДОБАВЛЕНО (моб-наблюдатель): сущность с механикой "Weeping Angel" из Doctor Who.
 *
 * Поведение:
 * - Когда игрок смотрит на моба (в пределах угла обзора) → моб ЗАМИРАЕТ (не двигается, статуя)
 * - Когда игрок НЕ смотрит на моба → моб БЫСТРО приближается к игроку
 * - При касании/атаке → наносит урон
 *
 * Технические детали:
 * - Проверка "смотрит ли игрок" делается через raycast от глаз игрока в направлении взгляда
 * - Если луч пересекает bounding box моба → игрок смотрит на него
 * - В замороженном состоянии моб неподвижен, в активном - очень быстр
 */
public class StalkerEntity extends AbstractNightmareEntity {

    /** Насколько быстро моб двигается когда игрок НЕ смотрит (множитель скорости) */
    private static final double STALKING_SPEED = 0.5;
    /** Насколько далеко моб может "видеть" игрока для преследования */
    private static final double DETECTION_RANGE = 32.0;
    /** Как часто проверять состояние "смотрит ли игрок" (каждые N тиков) */
    private static final int CHECK_INTERVAL = 5;

    /** Текущее состояние: true = заморожен (игрок смотрит), false = активен (преследует) */
    private boolean frozen = false;
    /** Счётчик тиков до следующей проверки состояния */
    private int ticksUntilCheck = 0;

    public StalkerEntity(class_1299<? extends class_1588> entityType, class_1937 world) {
        super(entityType, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1588.method_26918()
                .method_26868(class_5134.field_23716, 30.0)
                .method_26868(class_5134.field_23721, 8.0)
                .method_26868(class_5134.field_23719, STALKING_SPEED) // быстрый когда активен
                .method_26868(class_5134.field_23717, DETECTION_RANGE)
                .method_26868(class_5134.field_23718, 0.5); // трудно отбросить
    }

    @Override
    protected void method_5959() {
        // ВАЖНО: стандартные AI цели НЕ добавляем - у Stalker особая логика движения,
        // которая целиком реализована в tick() методе ниже.
        this.field_6201.method_6277(8, new class_1361(this, class_1657.class, 16.0f));
        this.field_6201.method_6277(8, new class_1376(this));

        // Цель атаки остаётся стандартной (касание = урон)
        this.field_6185.method_6277(1, new class_1399(this));
        this.field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_5770().method_8608()) return; // вся логика на сервере

        ticksUntilCheck--;
        if (ticksUntilCheck <= 0) {
            ticksUntilCheck = CHECK_INTERVAL;
            updateFrozenState();
        }

        // Если заморожен - полностью останавливаем движение
        if (frozen) {
            this.method_18799(class_243.field_1353);
            this.field_6007 = true;
        } else {
            // Если не заморожен - преследуем ближайшего игрока
            stalkNearestPlayer();
        }
    }

    /**
     * Обновляет состояние frozen: проверяет, смотрит ли хотя бы один игрок на этого моба.
     * Если хотя бы один смотрит → заморожен, иначе → активен.
     */
    private void updateFrozenState() {
        boolean anyPlayerLooking = false;

        // Ищем всех игроков в радиусе DETECTION_RANGE
        var nearbyPlayers = this.method_5770().method_8390(
                class_3222.class,
                this.method_5829().method_1014(DETECTION_RANGE),
                player -> player.method_5805() && !player.method_7325()
        );

        for (class_3222 player : nearbyPlayers) {
            if (isPlayerLookingAt(player)) {
                anyPlayerLooking = true;
                break;
            }
        }

        frozen = anyPlayerLooking;
    }

    /**
     * Проверяет, смотрит ли конкретный игрок на этого моба.
     *
     * Логика: raycast от глаз игрока в направлении взгляда. Если луч пересекает
     * bounding box моба в пределах дистанции обзора → игрок смотрит на моба.
     */
    private boolean isPlayerLookingAt(class_3222 player) {
        class_243 playerEyes = player.method_33571();
        class_243 playerLook = player.method_5720(); // направление взгляда

        double distance = playerEyes.method_1022(this.method_24515().method_46558());
        if (distance > DETECTION_RANGE) return false;

        // Raycast: луч от глаз игрока в направлении взгляда на длину = дистанция до моба + запас
        class_243 rayEnd = playerEyes.method_1019(playerLook.method_1021(distance + 2.0));

        // Проверяем пересечение луча с bounding box моба
        class_238 mobBox = this.method_5829().method_1014(0.5); // небольшой запас для удобства
        var hit = mobBox.method_992(playerEyes, rayEnd);

        return hit.isPresent();
    }

    /**
     * Преследует ближайшего игрока когда НЕ заморожен.
     * Движется ПРЯМО к игроку, игнорируя препятствия (как призрак).
     */
    private void stalkNearestPlayer() {
        var target = this.method_5968();
        class_1657 player;
        if (!(target instanceof class_1657)) {
            // Нет цели - ищем ближайшего игрока
            player = this.method_5770().method_18460(this, DETECTION_RANGE);
            if (player != null) {
                this.method_5980(player);
            }
        } else {
            player = (class_1657) target;
        }

        if (player == null || !player.method_5805()) return;

        // Вектор направления к игроку
        class_243 toPlayer = player.method_24515().method_46558().method_1020(this.method_24515().method_46558()).method_1029();

        // Устанавливаем скорость движения прямо к игроку
        this.method_18799(toPlayer.method_1021(STALKING_SPEED));
        this.field_6007 = true;

        // Поворачиваем голову в сторону игрока
        this.method_5988().method_6226(player, 30.0f, 30.0f);
    }

    /**
     * Stalker не получает урон пока заморожен (игрок смотрит на него).
     */
    public boolean damageWithWorld(net.minecraft.class_3218 world, class_1282 source, float amount) {
        if (frozen) {
            // Заморожен = неуязвим (каменная статуя)
            return false;
        }
        return super.method_5643(source, amount);
    }

    /**
     * Stalker не может быть отброшен назад - стоит как статуя когда заморожен,
     * и движется неумолимо когда активен.
     */
    @Override
    public void method_6005(double strength, double x, double z) {
        if (frozen) return; // заморожен = нет отбрасывания
        // Даже в активном состоянии - сильно снижаем отбрасывание
        super.method_6005(strength * 0.3, x, z);
    }

    /**
     * Визуальная подсказка: когда заморожен, моб светится (glowing effect),
     * чтобы игрок понимал что он "активен" как статуя.
     */
    @Override
    public boolean method_5851() {
        return frozen;
    }
}
