package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Watcher — обитатель «Пустоты с глазами». Классическая SCP-подобная механика:
 * замирает на месте (не двигается, не атакует), пока хотя бы один игрок смотрит
 * на него, но стремительно приближается и атакует в момент, когда все игроки
 * отводят взгляд. Заставляет пятиться назад, не отрывая взгляда — очень
 * атмосферная и напряжённая механика "не моргай".
 */
public class WatcherEntity extends AbstractNightmareEntity {

    private static final double VIEW_CONE_DOT_THRESHOLD = 0.7;

    public WatcherEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 40.0)
                .method_26868(class_5134.field_23719, 0.0) // "ходит" только рывками, см. tick()
                .method_26868(class_5134.field_23721, 10.0);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        boolean watchedByAnyone = this.method_5770().method_18456().stream()
                .filter(p -> p.method_5858(this) < 40 * 40)
                .anyMatch(this::isBeingWatchedBy);

        if (!watchedByAnyone) {
            // Рывок к ближайшему игроку, пока никто не смотрит
            class_1657 nearest = this.method_5770().method_18460(this, 40.0);
            if (nearest != null) {
                this.method_5942().method_6335(nearest, 1.6);
            }
        } else {
            this.method_5942().method_6340();
        }
    }

    private boolean isBeingWatchedBy(class_1657 player) {
        var lookVec = player.method_5828(1.0f).method_1029();
        var toEntity = this.method_19538().method_1020(player.method_33571()).method_1029();
        return lookVec.method_1026(toEntity) > VIEW_CONE_DOT_THRESHOLD;
    }
}
