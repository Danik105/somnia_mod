package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Screaming Miner — обитатель «Шахты-лабиринта».
 * Издаёт громкий крик при обнаружении игрока, который слышен по всей
 * шахте и призывает Blind Burrower'ов к позиции игрока (звуковая приманка).
 */
public class ScreamingMinerEntity extends AbstractNightmareEntity {

    private int screamCooldown = 0;

    public ScreamingMinerEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 22.0)
                .method_26868(class_5134.field_23719, 0.23)
                .method_26868(class_5134.field_23721, 4.5);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (screamCooldown > 0) {
            screamCooldown--;
        } else if (this.method_5968() != null) {
            this.method_5770().method_8396(null, this.method_24515(),
                    com.somnium.mod.registry.ModSounds.MINER_SCREAM, this.method_5634(), 2.5f, 1.0f);
            screamCooldown = 100; // раз в 5 секунд
            // TODO: оповестить всех ScreamingMinerEntity/BlindBurrowerEntity в радиусе о позиции цели
        }
    }
}
