package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Drowned Wretch — обитатель "Тонущего города".
 * Механика: получает бонус скорости и урона, если находится в воде или
 * если уровень воды в сне поднялся выше определённого порога (нагнетание паники
 * по мере затопления локации). На суше — медленный и слабый.
 */
public class DrownedWretchEntity extends AbstractNightmareEntity {

    public DrownedWretchEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 16.0)
                .method_26868(class_5134.field_23719, 0.18); // на суше медленный
    }

    @Override
    public void method_5773() {
        super.method_5773();
        boolean inWater = this.method_5799();
        // В воде — резко опаснее (эффект "паники утопающего")
        this.method_5996(class_5134.field_23719)
                .method_6192(inWater ? 0.32 : 0.18);
        this.method_5996(class_5134.field_23721)
                .method_6192(inWater ? 6.0 : 3.0);
    }

    @Override
    public boolean method_6094() {
        return true;
    }
}
