package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Nightmare Amalgam — уникальный босс сна «Сон-в-сне».
 * Циклически меняет "фазу", копируя механики других монстров:
 *  Фаза 1: как Watcher — замирает под взглядом
 *  Фаза 2: как Lurking Shade — становится невидимым
 *  Фаза 3: как Flesh Golem — атака по площади
 * Каждая фаза длится ~15 секунд, затем следующая — заставляет игрока
 * постоянно адаптировать тактику.
 */
public class NightmareAmalgamEntity extends AbstractNightmareEntity {

    private enum Phase { WATCHER, SHADE, GOLEM }

    private Phase currentPhase = Phase.WATCHER;
    private int phaseTimer = 0;
    private static final int PHASE_DURATION_TICKS = 300; // 15 секунд

    public NightmareAmalgamEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 150.0)
                .method_26868(class_5134.field_23719, 0.22)
                .method_26868(class_5134.field_23721, 8.0);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        phaseTimer++;
        if (phaseTimer >= PHASE_DURATION_TICKS) {
            phaseTimer = 0;
            currentPhase = switch (currentPhase) {
                case WATCHER -> Phase.SHADE;
                case SHADE -> Phase.GOLEM;
                case GOLEM -> Phase.WATCHER;
            };
            // TODO: визуальный/звуковой эффект смены фазы + партиклы искажения
        }
        // TODO: делегировать поведение конкретной фазы соответствующей логике
        // (переиспользовать методы WatcherEntity/LurkingShadeEntity/FleshGolemEntity через статические хелперы)
    }
}
