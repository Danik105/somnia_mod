package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Mirrored Double — обитатель «Пустоши зеркал».
 * Копирует силу атаки ближайшего игрока (немного слабее оригинала, чтобы
 * бой был выигрышным, но не тривиальным) и визуально похож на игрока
 * (модель/скин подставляется на клиенте, см. TODO в client-модуле).
 * Разбитое рядом зеркало-осколок порождает ещё одного двойника — важно
 * убить оригинал, не разбивая зеркала вокруг.
 */
public class MirroredDoubleEntity extends AbstractNightmareEntity {

    public MirroredDoubleEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 20.0)
                .method_26868(class_5134.field_23719, 0.24)
                .method_26868(class_5134.field_23721, 3.0);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        class_1657 target = this.method_5770().method_18460(this, 32.0);
        if (target != null) {
            double playerDamage = target.method_26825(class_5134.field_23721);
            this.method_5996(class_5134.field_23721)
                    .method_6192(Math.max(2.0, playerDamage * 0.8));
        }
    }

    // TODO: событие "разбито зеркало рядом" -> ModEntities.MIRRORED_DOUBLE.spawn(...) клон в той же точке
    // TODO: на клиенте подменять текстуру сущности скином ближайшего игрока (кастомный EntityRenderer)
}
