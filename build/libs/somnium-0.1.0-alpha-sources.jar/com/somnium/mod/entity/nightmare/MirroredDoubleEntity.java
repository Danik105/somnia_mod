package com.somnium.mod.entity.nightmare;

import com.somnium.mod.sanity.SanityManager;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1324;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Mirrored Double — обитатель «Зеркальных пустошей», центральная механика "Резонанс Двойника".
 *
 * Двойник никогда не преследует игрока напрямую: он стремится занять позицию, ЗЕРКАЛЬНУЮ
 * позиции игрока через Разлом (точку симметрии, задаёт DreamManager#setMirrorCenter):
 *     doubleTarget = 2 * mirrorCenter - playerPos
 * Поэтому вдали от Разлома он недосягаем, а у самого центра неизбежно сближается с игроком —
 * это единственное окно, чтобы его ударить. Но долгий контакт опасен: если игрок и Двойник
 * остаются ближе SYNC_RADIUS дольше SYNC_LIMIT_TICKS, происходит СИНХРОНИЗАЦИЯ — игрок получает
 * урон и теряет рассудок, а Двойник "рассыпается стеклом" и пересобирается на краю арены,
 * становясь чуть быстрее. Бой — серия коротких заходов к центру: успей нанести удары и отойти
 * до разрыва связи.
 *
 * Победа/поражение обрабатывает общий конвейер снов (BOSS_KILL / смерть в сне / таймаут).
 */
public class MirroredDoubleEntity extends AbstractNightmareEntity {

    /** Дистанция "опасного контакта": ближе — идёт накопление синхронизации */
    private static final double SYNC_RADIUS = 3.0;
    /** Сколько тиков непрерывного контакта выдерживает связь до синхронизации (3 секунды) */
    private static final int SYNC_LIMIT_TICKS = 60;
    /** Тики контакта, на которых игрок получает текстовые предупреждения */
    private static final int SYNC_WARN_FIRST = 20;
    private static final int SYNC_WARN_SECOND = 40;
    /** Куда "рассыпается" Двойник после синхронизации — кольцо вокруг Разлома */
    private static final double REFORM_MIN_RADIUS = 12.0;
    private static final double REFORM_MAX_RADIUS = 18.0;
    /** Рассудок, отнимаемый каждой синхронизацией */
    private static final float SYNC_SANITY_DAMAGE = -12.0f;
    /** Базовая скорость и её прирост за каждую синхронизацию (кап — чтобы бой оставался честным) */
    private static final double BASE_SPEED = 0.24;
    private static final double SPEED_PER_SYNC = 0.02;
    private static final double MAX_SPEED = 0.32;

    /** Точка симметрии арены — центр Разлома; задаёт DreamManager при спавне */
    private class_2338 mirrorCenter;
    /** Накопленные тики непрерывного контакта с игроком */
    private int syncTicks = 0;
    /** Сколько синхронизаций уже произошло — растит урон и скорость Двойника */
    private int syncCount = 0;

    public MirroredDoubleEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 20.0)
                .method_26868(class_5134.field_23719, BASE_SPEED)
                .method_26868(class_5134.field_23721, 3.0)
                .method_26868(class_5134.field_23717, 64.0);
    }

    /**
     * ИСПРАВЛЕНО: у Двойника нет стандартного боевого AI — он не ходит к игроку и не бьёт
     * сам. Движение полностью ручное (зеркалирование позиции), единственное "оружие" —
     * синхронизация при долгом контакте (см. tick()).
     */
    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new net.minecraft.class_1347(this));
    }

    public void setMirrorCenter(class_2338 center) {
        this.mirrorCenter = center;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_5770().method_8608()) return;
        if (!(this.method_5770() instanceof class_3218 serverWorld)) return;

        class_1657 closest = serverWorld.method_18460(this, 64.0);
        if (mirrorCenter == null || !(closest instanceof class_3222 player)) {
            // Без центра симметрии или игрока связь затухает
            syncTicks = Math.max(0, syncTicks - 2);
            if (syncTicks == 0) this.method_5834(false);
            return;
        }

        mirrorPlayerPosition(player);
        updateSynchronization(player, serverWorld);
    }

    /**
     * Двигает Двойника в точку, зеркальную позиции игрока через Разлом (центральная симметрия
     * в плоскости XZ). Пока игрок далеко от центра — Двойник далеко от игрока; подойти к нему
     * вплотную можно, только встав у самого Разлома.
     */
    private void mirrorPlayerPosition(class_3222 player) {
        double centerX = mirrorCenter.method_10263() + 0.5;
        double centerZ = mirrorCenter.method_10260() + 0.5;
        double mirroredX = 2.0 * centerX - player.method_23317();
        double mirroredZ = 2.0 * centerZ - player.method_23321();

        // Переиздаём приказ на движение периодически и когда навигация остановилась —
        // иначе моб "замирает", дойдя до устаревшей цели
        if (this.field_6012 % 5 == 0 || this.method_5942().method_6357()) {
            this.method_5942().method_6337(mirroredX, player.method_23318(), mirroredZ, 1.0);
        }

        // Двойник всегда смотрит на оригинал — как отражение в зеркале
        this.method_5988().method_35111(player);

        // Копирует "пластику" игрока: ускоряется, когда тот бежит
        this.method_5728(player.method_5624());
    }

    /**
     * Считает тики близкого контакта и разрывает связь, когда лимит исчерпан.
     * Контакт без прикосновения затухает вдвое быстрее, чем накапливается — короткие
     * заходы "ударил и отошёл" безопасны, стоять рядом — нет.
     */
    private void updateSynchronization(class_3222 player, class_3218 world) {
        double distance = this.method_5739(player);
        if (distance <= SYNC_RADIUS) {
            syncTicks++;
        } else {
            syncTicks = Math.max(0, syncTicks - 2);
        }

        // Двойник светится, пока копит резонанс — видимый индикатор опасности
        this.method_5834(syncTicks > 0);

        if (syncTicks == SYNC_WARN_FIRST) {
            player.method_7353(class_2561.method_43470("§5Отражение настраивается на тебя..."), true);
        } else if (syncTicks == SYNC_WARN_SECOND) {
            player.method_7353(class_2561.method_43470("§5§lСвязь вот-вот замкнётся — ОТОЙДИ!"), true);
        }

        // Звон стекла учащается по мере резонанса
        if (syncTicks > 0 && syncTicks % 10 == 0) {
            world.method_8396(null, this.method_24515(),
                    class_3417.field_26980,
                    class_3419.field_15251, 1.0f, 0.6f + 0.6f * ((float) syncTicks / SYNC_LIMIT_TICKS));
        }

        if (syncTicks >= SYNC_LIMIT_TICKS) {
            triggerSynchronization(player, world);
        }
    }

    /**
     * Разрыв зеркальной связи: игрок получает урон и теряет рассудок, Двойник "рассыпается"
     * и пересобирается на краю арены. Каждая синхронизация делает его чуть сильнее и быстрее.
     */
    private void triggerSynchronization(class_3222 player, class_3218 world) {
        syncCount++;
        syncTicks = 0;

        // Урон растёт с каждой синхронизацией — затягивать бой всё опаснее
        player.method_5643(world.method_48963().method_48831(), 3.0f + syncCount);
        SanityManager.get(player).addSanity(SYNC_SANITY_DAMAGE);
        player.method_6092(new class_1293(class_1294.field_5916, 100, 0));
        player.method_7353(class_2561.method_43470("§5§lВы синхронизировались с отражением — связь рвётся болью!"), true);

        // Отброс игрока от Двойника — физическое "размыкание" связи
        class_243 away = new class_243(player.method_23317() - this.method_23317(), 0, player.method_23321() - this.method_23321());
        if (away.method_1027() < 1.0E-4) {
            away = new class_243(this.field_5974.method_43058() - 0.5, 0, this.field_5974.method_43058() - 0.5);
        }
        away = away.method_1029().method_1021(1.2);
        player.method_5762(away.field_1352, 0.4, away.field_1350);
        player.field_6037 = true;

        // Двойник рассыпается стеклом...
        world.method_8396(null, this.method_24515(),
                class_3417.field_15081, class_3419.field_15251, 2.0f, 0.7f);
        world.method_14199(class_2398.field_23190,
                this.method_23317(), this.method_23318() + 1.0, this.method_23321(), 60, 0.4, 0.8, 0.4, 0.05);

        // ...и пересобирается в случайной точке кольца вокруг Разлома
        double angle = this.field_5974.method_43058() * Math.PI * 2;
        double dist = REFORM_MIN_RADIUS + this.field_5974.method_43058() * (REFORM_MAX_RADIUS - REFORM_MIN_RADIUS);
        double newX = mirrorCenter.method_10263() + 0.5 + Math.cos(angle) * dist;
        double newZ = mirrorCenter.method_10260() + 0.5 + Math.sin(angle) * dist;
        this.method_5808(newX, this.method_23318(), newZ, this.field_5974.method_43057() * 360f, 0);
        world.method_14199(class_2398.field_23190,
                newX, this.method_23318() + 1.0, newZ, 40, 0.4, 0.8, 0.4, 0.05);
        world.method_8396(null, this.method_24515(),
                class_3417.field_14879, class_3419.field_15251, 1.0f, 0.5f);

        // Эскалация: каждая синхронизация ускоряет Двойника
        var speedAttr = this.method_5996(class_5134.field_23719);
        if (speedAttr != null) {
            speedAttr.method_6192(Math.min(BASE_SPEED + SPEED_PER_SYNC * syncCount, MAX_SPEED));
        }
    }

    @Override
    public void method_6078(class_1282 damageSource) {
        super.method_6078(damageSource);

        // Зеркало разбито — звон стекла и вспышка частиц вместо обычной смерти
        if (this.method_5770() instanceof class_3218 serverWorld) {
            serverWorld.method_8396(null, this.method_24515(),
                    class_3417.field_15081, class_3419.field_15251, 2.5f, 0.5f);
            serverWorld.method_14199(class_2398.field_23190,
                    this.method_23317(), this.method_23318() + 1.0, this.method_23321(), 100, 0.6, 1.0, 0.6, 0.1);
        }
    }
}
