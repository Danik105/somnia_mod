package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1299;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * Blind Burrower — слепой крот-гигант «Шахты-лабиринта».
 * Не видит игрока напрямую (нет обычного line-of-sight таргетинга),
 * а реагирует на звук шагов/крик шахтёра и роет напрямик через блоки
 * к последней услышанной позиции — источник страха: он "знает", где вы.
 */
public class BlindBurrowerEntity extends AbstractNightmareEntity {

    public BlindBurrowerEntity(class_1299<? extends class_1588> type, class_1937 world) {
        super(type, world);
    }

    public static class_5132.class_5133 createAttributes() {
        return createNightmareAttributes()
                .method_26868(class_5134.field_23716, 30.0)
                .method_26868(class_5134.field_23719, 0.28)
                .method_26868(class_5134.field_23721, 7.0);
    }

    @Override
    protected void method_5959() {
        super.method_5959();
        // TODO: заменить стандартный targetSelector на кастомную "SoundTrackingGoal",
        // которая не использует зрение (canSee), а идёт к последней "услышанной" точке
        // и умеет ломать слабые блоки (землю/камень) на пути.
    }
}
