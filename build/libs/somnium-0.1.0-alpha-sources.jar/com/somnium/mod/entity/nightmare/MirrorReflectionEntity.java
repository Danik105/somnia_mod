package com.somnium.mod.entity.nightmare;

import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * НОВЫЙ КОШМАР: Зеркальное отражение игрока.
 *
 * Поведение:
 * 1. Спавнится напротив игрока через "зеркало" (невидимую плоскость)
 * 2. Копирует внешний вид игрока (скин, одежда)
 * 3. Зеркально повторяет движения игрока (если игрок идёт вперёд, отражение идёт назад)
 * 4. Через некоторое время начинает "ломать зеркало" и атаковать
 * 5. Издаёт жуткие звуки (стекло, искажённые звуки игрока)
 */
public class MirrorReflectionEntity extends AbstractNightmareEntity {

    private static final int BREAK_GLASS_DELAY = 400; // 20 секунд до начала атаки (400 тиков)
    private int ticksAlive = 0;
    private boolean glassBreaking = false;
    private class_3222 targetPlayer;
    private class_2338 mirrorPlanePos; // Центр "зеркала"

    public MirrorReflectionEntity(class_1299<? extends AbstractNightmareEntity> type, class_1937 world) {
        super(type, world);
        // ДОБАВЛЕНО: показываем ник (Custom Name Visible) для зеркального отражения
        this.method_5880(true);
    }

    /**
     * ИСПРАВЛЕНО: НЕ добавляем стандартный AI пока моб в зеркальном режиме.
     * Первые 20 секунд моб только повторяет движения игрока (без блуждания).
     * После разбития стекла - добавляем боевой AI.
     */
    @Override
    protected void method_5959() {
        // В начале НЕ добавляем никаких AI целей - моб полностью контролируется вручную
        // через mirrorPlayerMovement(). AI будет добавлен позже в startAttacking().
    }

    public static class_5132.class_5133 createMirrorReflectionAttributes() {
        return AbstractNightmareEntity.createNightmareAttributes()
                .method_26868(class_5134.field_23716, 30.0)
                .method_26868(class_5134.field_23719, 0.28)
                .method_26868(class_5134.field_23721, 6.0)
                .method_26868(class_5134.field_23717, 64.0);
    }

    public void setTargetPlayer(class_3222 player) {
        this.targetPlayer = player;
        // ДОБАВЛЕНО: устанавливаем ник игрока как имя моба
        if (player != null) {
            this.method_5665(player.method_5477());
        }
    }

    public void setMirrorPlane(class_2338 pos) {
        this.mirrorPlanePos = pos;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_5770().method_8608()) return;

        ticksAlive++;

        // ИСПРАВЛЕНИЕ: не удаляем моба, если он еще не инициализирован (первые 30 тиков)
        // targetPlayer устанавливается через ~10 тиков после спавна, даем время на инициализацию
        if (ticksAlive > 30) {
            if (targetPlayer == null || !targetPlayer.method_5805()) {
                this.method_31472();
                return;
            }
        }

        // Первые 20 секунд - зеркальное отражение (молчаливое следование)
        if (ticksAlive < BREAK_GLASS_DELAY) {
            // ДОБАВЛЕНО: логирование для отладки
            if (ticksAlive % 20 == 0) { // Раз в секунду
                if (mirrorPlanePos == null) {
                    com.somnium.mod.SomniumMod.LOGGER.warn("[MirrorReflection] mirrorPlanePos is NULL!");
                } else {
                    com.somnium.mod.SomniumMod.LOGGER.info("[MirrorReflection] Following player. Mirror at X={}, Player at X={}, Mob at X={}",
                        mirrorPlanePos.method_10263(), targetPlayer.method_23317(), this.method_23317());
                }
            }
            mirrorPlayerMovement();

            // Звук стекла при начале "трещин" (за 1 секунду до атаки)
            if (ticksAlive == BREAK_GLASS_DELAY - 20) {
                this.method_5770().method_8396(null, this.method_24515(),
                        class_3417.field_15081,
                        net.minecraft.class_3419.field_15251,
                        2.0f, 0.5f);
            }
        }
        // После - начинаем атаку
        else if (!glassBreaking) {
            glassBreaking = true;
            startAttacking();
        }

        // ИЗМЕНЕНО: жуткие звуки только ПОСЛЕ начала атаки (не во время зеркального следования)
        if (glassBreaking && ticksAlive % 60 == 0) {
            this.method_5770().method_8396(null, this.method_24515(),
                    class_3417.field_14713,
                    net.minecraft.class_3419.field_15251,
                    1.0f, 0.3f);
        }
    }

    /**
     * ИСПРАВЛЕНО: Зеркально копирует движения игрока через стекло.
     * Моб находится ЗА СТЕКЛОМ и повторяет действия игрока зеркально,
     * пока стекло не разобьётся через 20 секунд.
     */
    private void mirrorPlayerMovement() {
        if (mirrorPlanePos == null || targetPlayer == null) return;

        class_243 playerPos = new class_243(targetPlayer.method_23317(), targetPlayer.method_23318(), targetPlayer.method_23321());

        // ИСПРАВЛЕНО: вычисляем зеркальную позицию относительно плоскости стекла
        // Стекло на mirrorPlanePos.X (это X координата центра стекла)
        // Если игрок на расстоянии D слева от стекла, моб на расстоянии D справа
        double mirrorX = mirrorPlanePos.method_10263();
        double distanceFromMirror = playerPos.field_1352 - mirrorX; // Расстояние игрока от стекла
        double mirroredX = mirrorX - distanceFromMirror; // Зеркальная позиция

        // Телепортируем отражение в зеркальную позицию
        this.method_5814(mirroredX, playerPos.field_1351, playerPos.field_1350);

        // ИСПРАВЛЕНО: сбрасываем velocity чтобы моб не продолжал двигаться по инерции
        this.method_18800(0, 0, 0);

        // ИСПРАВЛЕНО: моб смотрит в зеркально противоположную сторону
        // В Minecraft yaw: 0°=юг, 90°=запад, 180°=север, 270°=восток
        // Для зеркала по оси X: mirroredYaw = -playerYaw
        float mirroredYaw = -targetPlayer.method_36454();
        this.method_36456(mirroredYaw);
        this.field_6241 = mirroredYaw; // Поворот головы тоже синхронизируем
        this.field_6283 = mirroredYaw; // И тела

        // Pitch остаётся таким же (наклон вверх/вниз не зеркалится горизонтальным зеркалом)
        this.method_36457(targetPlayer.method_36455());

        // Копируем анимацию (приседание, спринт и т.д.)
        this.method_5660(targetPlayer.method_5715());
        this.method_5728(targetPlayer.method_5624());
    }

    /**
     * Начинает агрессивное преследование игрока после "разбития зеркала"
     */
    private void startAttacking() {
        // Звук разбитого стекла
        this.method_5770().method_8396(null, this.method_24515(),
                class_3417.field_15081,
                net.minecraft.class_3419.field_15251,
                3.0f, 0.3f);

        // ДОБАВЛЕНО: накладываем эффект слепоты на игрока ПОСЛЕ звука стекла
        if (targetPlayer != null && targetPlayer.method_5805()) {
            targetPlayer.method_6092(new net.minecraft.class_1293(
                    net.minecraft.class_1294.field_5919,
                    400, // 20 секунд (остаток сна)
                    1, // уровень II (сильная слепота)
                    false, false, true
            ));
        }

        // Устанавливаем цель атаки
        this.method_5980(targetPlayer);

        // Увеличиваем скорость для рывка
        this.method_5996(class_5134.field_23719).method_6192(0.35);

        // ДОБАВЛЕНО: теперь включаем боевой AI (ранее был отключен)
        this.field_6201.method_6277(0, new net.minecraft.class_1347(this));
        this.field_6201.method_6277(1, new net.minecraft.class_1366(this, 1.2, false));
        this.field_6201.method_6277(2, new net.minecraft.class_1361(this, class_1657.class, 12.0f));
        this.field_6185.method_6277(1, new net.minecraft.class_1399(this));
        this.field_6185.method_6277(2, new net.minecraft.class_1400<>(this, class_1657.class, true));
    }

    @Override
    public void method_6078(class_1282 damageSource) {
        super.method_6078(damageSource);

        // Звук разбитого зеркала при смерти
        if (!this.method_5770().method_8608()) {
            this.method_5770().method_8396(null, this.method_24515(),
                    class_3417.field_15081,
                    net.minecraft.class_3419.field_15251,
                    2.0f, 1.0f);
        }
    }
}
