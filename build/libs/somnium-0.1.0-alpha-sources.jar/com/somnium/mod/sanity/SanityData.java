package com.somnium.mod.sanity;

import net.minecraft.class_2487;

/**
 * Чистые данные рассудка одного игрока.
 * Хранятся в персистентных данных игрока (см. SanityManager#load/save)
 * через стандартный механизм PersistentState / кастомные NBT-теги на PlayerEntity.
 */
public final class SanityData {

    public static final float MAX_SANITY = 100.0f;
    public static final float MIN_SANITY = 0.0f;

    /** Текущий рассудок игрока, 0..100 */
    private float sanity = MAX_SANITY;

    /** Сколько тиков прошло с последнего успешного сна */
    private long ticksSinceLastSleep = 0L;

    /** Идентификатор последнего пройденного сна — нужен для Bleed-Through (спавн "родных" монстров) */
    private String lastDreamId = "";

    public float getSanity() {
        return sanity;
    }

    public void setSanity(float value) {
        this.sanity = Math.max(MIN_SANITY, Math.min(MAX_SANITY, value));
    }

    public void addSanity(float delta) {
        setSanity(this.sanity + delta);
    }

    public long getTicksSinceLastSleep() {
        return ticksSinceLastSleep;
    }

    public void setTicksSinceLastSleep(long ticks) {
        this.ticksSinceLastSleep = ticks;
    }

    public void resetSleepTimer() {
        this.ticksSinceLastSleep = 0L;
    }

    public String getLastDreamId() {
        return lastDreamId;
    }

    public void setLastDreamId(String lastDreamId) {
        this.lastDreamId = lastDreamId;
    }

    public class_2487 writeNbt(class_2487 nbt) {
        nbt.method_10548("Sanity", sanity);
        nbt.method_10544("TicksSinceLastSleep", ticksSinceLastSleep);
        nbt.method_10582("LastDreamId", lastDreamId);
        return nbt;
    }

    public static SanityData readNbt(class_2487 nbt) {
        SanityData data = new SanityData();
        data.sanity = nbt.method_10545("Sanity") ? nbt.method_10583("Sanity") : MAX_SANITY;
        data.ticksSinceLastSleep = nbt.method_10545("TicksSinceLastSleep") ? nbt.method_10537("TicksSinceLastSleep") : 0L;
        data.lastDreamId = nbt.method_10545("LastDreamId") ? nbt.method_10558("LastDreamId") : "";
        return data;
    }
}
